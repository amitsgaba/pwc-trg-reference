/**
 * Created by Ramkumar on 3/10/2016.
 */

(function () {

    var fileDependencies =
        [
            'logger',
            'arrayutils'
        ];

    define(fileDependencies, function (Logger) {

        function StockValidator() {
            this.logger = new Logger();
        }

        StockValidator.registeredProducts = ['P1', 'P2', 'P3', 'P4', 'P5'];

        StockValidator.prototype.isStockAvailable =
            function (productId, units) {
                var MIN_UNITS = 1;
                var MAX_UNITS = 100;

                var validation = productId && units &&
                    units >= MIN_UNITS && units <= MAX_UNITS &&
                    StockValidator.registeredProducts.isExist(productId);

                this.logger.log("Validation Status : (Stock) : " + validation);

                return validation;
            };

        return StockValidator;
    });

})();

