/**
 * Created by Ramkumar on 3/10/2016.
 */
function Provider1() {
    this.a = 10;
    this.b = 20;
}

function Provider2() {
    this.x = 20;
    this.y = 40;
    this.b = 30;
}

var obj = {};

Provider1.call(obj);
Provider2.call(obj);

for (var property in obj) {
    console.log(property + " : " + obj[property]);
}