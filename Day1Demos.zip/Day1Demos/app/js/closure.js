/**
 * Created by Ramkumar on 3/10/2016.
 */

function Iterator() {
    /* These variables used in Closure to achieve data hiding */
    var parameters = arguments;
    var index = 0;

    return function () {
        if (index >= parameters.length) {
            throw {
                name: 'Index Error',
                message: 'Invalid Index Specified!'
            };
        }

        return parameters[index++];
    };
}

var iterator = Iterator(10, 20, 30, 40, 50);

try {
    while (true) {
        console.log(iterator());
    }
} catch (error) {
    console.log("Error Occurred, Details : " +
        error.name + ", " + error.message);
}