/**
 * Created by Ramkumar on 3/10/2016.
 */

(function () {

    var fileDependencies =
        [
            'logger',
            'creditcardvalidator',
            'stockvalidator'
        ];

    define(fileDependencies, function (Logger, CreditCardValidator, StockValidator) {

        function OrderProcessor() {
            this.logger = new Logger();
            this.creditCardValidator = new CreditCardValidator();
            this.stockValidator = new StockValidator();
        }

        OrderProcessor.prototype.process =
            function (order) {
                var validation = order &&
                    order.orderId && order.orderDate <= new Date() &&
                    order.customer && order.creditCardNumber &&
                    order.productId && order.units && order.amount;

                if (!validation) {
                    throw {
                        name: 'Input Validation',
                        message: 'Invalid Order Details Specified!'
                    };
                }

                var stockValidation = this.stockValidator.isStockAvailable(order.productId, order.units);
                var creditCardValidation = this.creditCardValidator.validate(order.creditCardNumber);
                var status = stockValidation && creditCardValidation;

                if (!status) {
                    throw {
                        name: 'Business Validation',
                        message: 'Business Validation Failed!'
                    };
                }

                this.logger.log("Business Validation Successfully Completed ...");
                this.logger.log("Order Processing Completed ...");

                return status;
            };

        return OrderProcessor;
    });

})();