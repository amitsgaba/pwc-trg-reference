/**
 * Created by Ramkumar on 3/10/2016.
 */

function HeavyWorker(minimum, maximum) {
    this.minimum = minimum;
    this.maximum = maximum;
}

HeavyWorker.prototype.doHeavyWork = function () {
    var output = 0;

    for (var outerCounter = this.minimum; outerCounter <= this.maximum; outerCounter++) {
        for (var innerCounter = this.minimum; innerCounter <= this.maximum; innerCounter++) {
            output++;
        }
    }

    return output;
};