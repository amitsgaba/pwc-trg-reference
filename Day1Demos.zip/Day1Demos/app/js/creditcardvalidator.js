/**
 * Created by Ramkumar on 3/10/2016.
 */

(function() {

    var fileDependencies =
        [
            'logger'
        ];

    define(fileDependencies, function(Logger) {
        
        function CreditCardValidator() {
            this.logger = new Logger();
            this.CC_PATTERN = /^\d{4}-\d{4}-\d{4}-\d{4}$/;
        }

        CreditCardValidator.prototype.validate = function (ccNumber) {
            var CC_NUMBER_LENGTH = 19;

            var validation = ccNumber &&
                ccNumber.length === CC_NUMBER_LENGTH &&
                this.CC_PATTERN.test(ccNumber);

            this.logger.log('Validation Status (CreditCard) : ' + validation);

            return validation;
        };

        return CreditCardValidator;
    });

})();

