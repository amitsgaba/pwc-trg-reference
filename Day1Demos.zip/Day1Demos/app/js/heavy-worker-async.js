/**
 * Created by Ramkumar on 3/10/2016.
 */
importScripts("heavy-worker.js");

onmessage = function (message) {
    console.log("Messagse Received and Work Started ... " +
        message.data.minimum + ", " + message.data.maximum);
    var minimum = message.data.minimum;
    var maximum = message.data.maximum;

    var heavyWorker = new HeavyWorker(minimum, maximum);
    var output = heavyWorker.doHeavyWork();

    postMessage({
        result: output
    });
};