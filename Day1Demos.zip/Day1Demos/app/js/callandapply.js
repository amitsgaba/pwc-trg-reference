/**
 * Created by Ramkumar on 3/10/2016.
 */
function Customer(id, name, address, credit, status) {
    this.id = id;
    this.name = name;
    this.address = address;
    this.credit = credit;
    this.status = status;
}

Customer.prototype.format = function () {
    return this.id + ', ' + this.name + ', ' +
        this.address + ', ' + this.credit + ', ' +
        this.status;
};

function InternetCustomer(id, name, address, credit, status, blogUrl) {
    // Customer.call(this, id, name, address, credit, status); // FASTER EXECUTION

    Customer.apply(this, arguments); // FLEXIBILITY IN INVOCATION

    this.blogUrl = blogUrl;
}

InternetCustomer.prototype = new Customer(); // Relationship established
InternetCustomer.prototype.constructor = InternetCustomer;

var internetCustomer = new InternetCustomer(
    10, 'Ponkumar', 'Bangalore', 1000, true, 'http://blogs.pwc.com/ponkumar');

console.log(typeof internetCustomer);
console.log(internetCustomer instanceof Customer);
console.log(internetCustomer instanceof InternetCustomer);

console.log(typeof InternetCustomer.prototype);
console.log(typeof InternetCustomer.prototype.constructor);
console.log(InternetCustomer.prototype.constructor);