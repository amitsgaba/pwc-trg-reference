/**
 * Created by Ramkumar on 3/10/2016.
 */

(function () {

    var fileDependencies =
        [];

    define(fileDependencies, function () {
        Array.prototype.isExist = function (item) {
            var status = false;

            for (var index in this) {
                if (this[index] === item) {
                    status = true;
                    break;
                }
            }

            return status;
        };
    });

})();