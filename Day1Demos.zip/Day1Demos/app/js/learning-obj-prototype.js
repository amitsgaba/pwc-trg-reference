/**
 * Created by Ramkumar on 3/10/2016.
 */
var obj = {
    id: 10,
    name: 'Ramkumar'
};

function Person() {}

Person.prototype.work = function() {
    console.log("Person Working ... " +
        this.id + ", " + this.name);
};

console.log(obj instanceof Person);

obj.__proto__ = new Person();

console.log(obj instanceof Person);
obj.work();