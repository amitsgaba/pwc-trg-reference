/**
 * Created by Ramkumar on 3/10/2016.
 */
function Customer(id, name, address, credit, status) {
    this.id = id;
    this.name = name;
    this.address = address;
    this.credit = credit;
    this.status = status;
}

function CustomerProvider() {
    this.url = "data/customers.json";
}

CustomerProvider.prototype.load = function (callback) {
    var request = new XMLHttpRequest();
    var READY_STATE = 4;
    var HTTP_OK = 200;

    request.onreadystatechange = function () {
        if (request.readyState === READY_STATE && request.status === HTTP_OK) {
            var responseText = request.responseText;
            var customers = JSON.parse(responseText);

            for (var index in customers) {
                customers[index].__proto__ = new Customer();
            }

            if (typeof callback === 'function') {
                callback(customers);
            }
        }
    };

    request.open('GET', this.url);
    request.send();
};

Customer.prototype.toHtml = function () {
    var markup = '';

    if (this) {
        markup +=
            '<tr>' +
            '<td>' + this.id + '</td>' +
            '<td>' + this.name + '</td>' +
            '<td>' + this.address + '</td>' +
            '<td>' + this.credit + '</td>' +
            '<td>' + this.status + '</td>' +
            '</tr>';
    }

    return markup;
};

function CustomersView(customers) {
    this.customers = customers;
}

CustomersView.prototype.render = function (callback) {
    if (typeof callback === 'function') {
        var markup = '';

        if (this.customers) {
            markup = '<table>';
            markup +=
                '<thead>' +
                '<tr>' +
                '<th> Customer # </th>' +
                '<th> Name </th>' +
                '<th> Address </th>' +
                '<th> Credit </th>' +
                '<th> Status </th>' +
                '</tr>' +
                '</thead>';

            markup += '<tbody>';

            for (var index in this.customers) {
                var customer = this.customers[index];

                markup += customer.toHtml();
            }

            markup += '</tbody>';
            markup += '</table>';

            callback(markup);
        }
    }
};

document.getElementById("btn-load").onclick =
    function () {
        var customerDataProvider = new CustomerProvider();

        customerDataProvider.load(
            function (data) {
                var customersView = new CustomersView(data);

                customersView.render(
                    function (markup) {
                        document.getElementById("customer-result").innerHTML = markup;
                    });
            });
    };