/**
 * Created by Ramkumar on 3/10/2016.
 */

document.getElementById("btn-start-work").onclick =
    function () {
        var startTime = new Date();
        var heavyWorker = new HeavyWorker(1, 500000);
        var heavyWorkOutput = heavyWorker.doHeavyWork();
        var endTime = new Date();
        var timeElapsed = (endTime - startTime);

        window.alert("Heavy Work Output : " +
            heavyWorkOutput + " Completed in (ms) " + timeElapsed);
    };

document.getElementById("btn-start-work-async").onclick =
    function () {
        if (window.Worker === 'undefined') {
            window.alert("Your browser doesn't support Web Workers API Features!");
            return;
        }

        var startTime = new Date();
        var worker = new Worker("js/heavy-worker-async.js");

        worker.onmessage = function (message) {
            var endTime = new Date();

            console.log("Message Received from Worker ... " +
                message.data.result + " Time Elapsed in ms ... " +
                (endTime - startTime));
        };

        worker.postMessage({
            minimum: 1,
            maximum: 50000
        });
    };