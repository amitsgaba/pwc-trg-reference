/**
 * Created by Ramkumar on 3/10/2016.
 */
function Customer(id, name, address, credit, status) {
    this.id = id;
    this.name = name;
    this.address = address;
    this.credit = credit;
    this.status = status;
}

Customer.prototype.format = function () {
    return this.id + ', ' + this.name + ', ' +
        this.address + ', ' + this.credit + ', ' +
        this.status;
};

function InternetCustomer(id, name, address, credit, status, blogUrl) {
    Customer.apply(this, arguments);

    this.blogUrl = blogUrl;
}

InternetCustomer.prototype = new Customer(); // Relationship established
InternetCustomer.prototype.constructor = InternetCustomer;

InternetCustomer.prototype.format = function() {
    var formattedMessage = Customer.prototype.format.call(this);

    return formattedMessage + ", " + this.blogUrl;
};

var internetCustomer = new InternetCustomer(
    1, 'Chandan', 'Bangalore', 10000, true, 'http://blogs.pwc.com/chandan');

console.log(internetCustomer.format());