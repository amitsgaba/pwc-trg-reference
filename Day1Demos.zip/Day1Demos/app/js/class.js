/**
 * Created by Ramkumar on 3/10/2016.
 */
function Customer(id, name, address, credit, status) {
    this.id = id;
    this.name = name;
    this.address = address;
    this.credit = credit;
    this.status = status;
}

Customer.prototype.format = function () {
    var message = '';

    for (var property in this) {
        if (typeof this[property] !== 'function') {
            message += this[property] + ', ';
        }
    }

    return message;
};

Array.prototype.isExist = function (item) {
    var status = false;

    for (var index in this) {
        if (this[index] === item) {
            status = true;
            break;
        }
    }

    return status;
};

var customer = new Customer(10, 'Rajkumar', 'Bangalore', 10000, true);

console.log(customer.format());

console.log(['Ramkumar','Rajkumar','Ramesh'].isExist(customer.name)); // GOOD
console.log(['Ramkumar','Rajkumar','Ramesh'].isExist(customer["name"])); // SHOULD BE AVOIDED