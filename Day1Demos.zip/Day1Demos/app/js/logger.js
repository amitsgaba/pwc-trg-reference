/**
 * Created by Ramkumar on 3/10/2016.
 */

(function () {

    var fileDependencies = [];

    define(fileDependencies, function () {
        function Logger() {
            this.format = 'Text';
        }

        Logger.prototype.log = function (message, type) {
            type = type || 'INFO';

            var formattedMessage = '';

            if (this.format === 'Text') {
                formattedMessage = type + ":" +
                    new Date().toString() + ":" +
                    message.toString().toUpperCase();

            }

            console.log(formattedMessage);
        };

        return Logger;
    });

})();

