/**
 * Created by Ramkumar on 3/10/2016.
 */

require.config({
    baseUrl: 'js',
    paths: {
        'jquery': '../bower_components/jquery/dist/jquery.min',
        'bootstrap': '../bower_components/bootstrap/dist/js/bootstrap.min'
    },
    shim: {
        'bootstrap': {
            deps: ['jquery'],
            export: 'bootstrap'
        },
        'orderprocessor': {
            deps: ['bootstrap'],
            export: 'orderprocessor'
        }
    }
});

document.getElementById("btn-process").onclick =
    function () {
        require(['orderprocessor'],
            function (OrderProcessor) {
                var processor = new OrderProcessor();
                var status = processor.process({
                    orderId: 'ORD10001',
                    orderDate: new Date('2005-06-06'),
                    customer: 'C10001',
                    productId: 'P1',
                    creditCardNumber: '1111-1111-1111-1111',
                    units: 100,
                    amount: 2000
                });

                console.log('Processing Status : ' + status);
            });
    };